# Agbsave9
_Tool to extract and inject agb_firm saves._

## How to use
1. Open the AGB_FIRM game you want to extract the save from.
2. Run the program and press A to dump the save as agb_dump.sav .

**Note eeprom games do not work yet.**

## Work in progress
* Fix eeprom games.
* Code the save injecter.